Copy this llink after installing android file

https://pieuu16952121.com/link/7lPnTqME4apTGmsf